var express = require('express');
var router = express.Router();
var movies = require('../controllers/movies');

router.get('/', movies.get);
router.get('/:id', movies.getOne);
router.post('/', movies.post);
router.put('/:id', movies.put);
router.delete('/:id', movies.delete);

module.exports = router;