var mongoose = require('mongoose');
var colors = require('colors');
    mongoose.connect('mongodb://localhost:27017/movieCRUD');
    var db = mongoose.connection;
    db.on('error', function(err){
        console.log(colors.red(err));
    });
    db.once('open', function(){
        console.log('Connected to mongodb server.'.green);
    });
module.exports = db;