var mongo = require('mongoose'),  
Schema = mongo.Schema;    

var moviesSchema = new Schema({
    title: String,
    director: String,
    releaseYear: Number,
    genre: String
});

var Movie = mongo.model('movies', moviesSchema);

module.exports = Movie;