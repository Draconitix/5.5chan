var exports = module.exports = {};
var mongoose = require('mongoose'),
Movie = require('../models/movies');    
require('../config/db');

var callback = function(err, docs, req, res){
    if(err)  return res.end(err);
    if(docs.length > 1){
        res.send(docs);
    } else {
        res.send(docs[0]);
    }
};

exports.get = function(req, res){
    Movie.find({}, function (err, docs){
        if(err) return callback(err, null, req, res);
        callback(null, docs, req, res);
    });
};

exports.getOne = function(req, res){
    Movie.find({ _id: req.params.id }, function (err, docs){
        if(err) return callback(err, null, req, res);
        callback(null, docs, req, res);
    });
};

exports.post = function(req, res){
    var document = new Movie(req.body);
    document.save(function(err, docs){
        if(err) return callback(err, null, req, res);
        callback(null, docs, req, res);
        console.log(docs);
    })
};

exports.put = function(req, res){
    Movie.update({ _id: req.params.id }, {$set: req.body }, function(err, docs){
        if(err) return callback(err, null, req, res);
        callback(null, docs, req, res);
    });
};

exports.delete = function(req, res){
    Movie.remove({ _id: req.params.id }, function (err, docs){
        if(err) return callback(err, null, req, res);
        callback(null, docs, req, res);
    });
};