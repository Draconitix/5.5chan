var app = angular.module('movieApp', ['ui.router', 'ngResource']);

app.config(function($interpolateProvider) {
  $interpolateProvider.startSymbol('{[{');
  $interpolateProvider.endSymbol('}]}');
});